require('./lib/node_loader');
module.exports = require('./lib/core');